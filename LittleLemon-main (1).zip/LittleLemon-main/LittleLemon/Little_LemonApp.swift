//
//  Little_LemonApp.swift
//  Little Lemon
//
//  Created by R.A. on 18/12/24.
//

import SwiftUI

@main
struct Little_LemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
